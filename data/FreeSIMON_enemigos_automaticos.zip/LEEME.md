# FreeSIMON — Modalidad local con enemigos automáticos

## Instalación

Este paquete modifica el desierto basándose en escenario(3).js y personajeD_completo.js que adjuntaste, e incluye la integración de flechas de la entrega anterior.

1. Guarda una copia de tus archivos actuales.
2. En data, reemplaza escenario.js, personajeD_completo.js y proyectiles_arco.js por los completos de este paquete.
3. Agrega en data los nuevos enemigos.config.js, enemigos.js y combate.js.
4. En escenario.html, conserva los scripts que ya cargan la configuración del desierto, personaje.js, la vida, BotiquinesJugador y TemporizadorJuego. Sustituye las etiquetas de los tres archivos reemplazados y agrega los nuevos, usando este orden:

```html
<!-- Mantén ANTES de este bloque tus scripts existentes de:
     configuración del desierto, personaje.js, vida,
     botiquines del escenario y temporizador. -->
<script src="personajeD_completo.js?v=npc-1"></script>
<script src="enemigos.config.js?v=npc-1"></script>
<script src="proyectiles_arco.js?v=npc-1"></script>
<script src="enemigos.js?v=npc-1"></script>
<script src="combate.js?v=npc-1"></script>
<script src="escenario.js?v=npc-1"></script>
```

No dupliques etiquetas. No hace falta copiar parches dentro de los archivos: los seis JS están completos y conectados. No se modifica personaje.js ni el sistema de vida. El cuerpo visual del HTML se conserva; se agregan al mundo las marcas de los enemigos.

Recarga con Ctrl+F5.

## Reglas

- 12 plazas de enemigos por defecto; cantidad configurable de 0 a 20.
- Cada aparición elige al azar un personaje del catálogo PersonajesKaku de tu personaje.js y una de las cinco armas configuradas. Puede repetirse el personaje y pueden coexistir duplicados.
- Aparición aleatoria a 18–65 unidades del jugador, dentro del mapa y fuera de los obstáculos registrados y otros enemigos. Si no hay sitio seguro, reintenta después de un segundo.
- Patrullan y, al verte a 28 unidades con línea de visión, te persiguen. Pierden el rastro más allá de 38 unidades.
- Una marca roja distingue al enemigo de tu personaje. Una marca amarilla anuncia su ataque durante 0,55 s.
- Espada/hacha atacan de cerca; arco dispara flechas y pistola/metralleta disparan proyectiles visibles. Cada ataque NPC tiene una pausa de aproximadamente 2,8–3,4 s para poder esquivarlo.
- Cualquier impacto válido del jugador elimina un NPC. Espada/hacha requieren distancia y dirección; arco/pistola/metralleta requieren que el proyectil alcance el cuerpo.
- El enemigo vuelve a aparecer tras 5 segundos de juego activo. No vuelve necesariamente el mismo personaje ni el mismo arma. La cantidad nunca crece por encima de las plazas configuradas.
- Pausa, preguntas y derrota detienen la simulación y el tiempo de reaparición. Los enemigos no atacan mientras respondes.
- Los golpes enemigos usan EquipoJugador.recibirDano(1): se conservan cinco corazones, escudos, inmunidad tras impacto y regreso a la sala.
- Los ataques de NPC no dañan a otros NPC. Los proyectiles del jugador no dañan al propio jugador.
- Al regresar a la sala y volver a entrar se inicia una nueva población local; no se guardan enemigos en sessionStorage.

## Controles

WASD desplazamiento; ratón/flechas orientar; E cofres; Q sacar/guardar arma; F o clic usar; 1–5 seleccionar armas; H botiquín; G escudo. Se conserva la tecla R de daño de prueba que existía en tu archivo adjunto.

Necesitas recoger un arma antes de atacar. La distancia corta admite un enemigo por golpe y comprueba que no haya un obstáculo entre ambos.

## Cambiar cantidad

Abre enemigos.config.js y cambia:

```javascript
cantidad: 12,
```

por cantidad: 15 para la siguiente prueba. Puedes subir hasta 20, pero primero comprueba FPS en tu laptop. No hay garantía de FPS ni prueba realizada en el hardware del usuario. El motor evita calcular una cámara por NPC, limita proyectiles a 48 y no dibuja NPC lejanos.

## Arquitectura y alcance

- enemigos.config.js: cantidad y dificultad.
- enemigos.js: modelos aleatorios, movimiento, aparición y reaparición.
- combate.js: alcance, blancos y aplicación de impactos.
- proyectiles_arco.js: flechas y balas con dueño, gravedad y colisiones por segmentos.
- personajeD_completo.js: permite modeloId y soloModelo para NPC; conserva la selección del jugador.
- escenario.js: integra simulación y dibujo en el bucle existente. Se conservan clima, preguntas, botiquines del mapa y temporizador; la llamada a curación del suelo admite recuperarCorazon o recuperarCorazones.

Es una modalidad para un jugador contra NPC en el navegador. No sincroniza enemigos entre equipos LAN; esa autoridad debe trasladarse al servidor cuando conectemos el multijugador. No incluye munición limitada, puntuación educativa por bajas ni recompensas: solo muestra un contador de eliminaciones en el aviso y emite escenario:enemigo-eliminado.

La navegación usa desvíos locales y los obstáculos registrados; no es un buscador de rutas para laberintos. Elementos decorativos sin colisión registrada no bloquean disparos ni movimiento. Arco conserva caída por gravedad; las balas viajan rectas. La dirección inicial sigue la mira, por lo que las flechas caen por debajo del punto apuntado a distancia.

## Verificación realizada

Sintaxis de seis JS; creación de doce modelos reales del catálogo; distancia de aparición; reaparición a cinco segundos; eliminación única; ataque cercano bloqueado por pared; proyectiles distinguiendo jugador/NPC; rechazo de daño bajo protección; simulación y 4.070 cargas de geometría con coordenadas finitas usando un contexto gráfico simulado.

Falta la prueba visual y de rendimiento en tu proyecto completo: no se adjuntaron escenario.html ni los módulos actuales de botiquines, temporizador y vida. Conserva esas dependencias existentes.
